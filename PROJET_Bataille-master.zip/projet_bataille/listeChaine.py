#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 22 20:44:35 2020

@author: manu
"""


class Maillon:
    """Un maillon d'une liste chaînée."""
    def __init__(self, valeur, suivant):
        self.valeur = valeur
        self.suivant = suivant

    def __str__(self):
        """Renvoie une chane de caractères représentant le maillon."""
        return str(self.valeur)


class ListeChaine:
    """Une liste chaînée."""
    def __init__(self, tete=None):
        """Crée une liste vide, ou une liste dont la tete (un maillon)
        est donnée."""
        self.__tete = tete

    def est_vide(self):
        """Indique si la liste est vide."""
        return self.__tete is None

    def tete(self):
        """Renvoie la valeur du premier élément de la liste."""
        if self.est_vide():
            raise IndexError("La liste vide n'a pas de tête")
        return self.__tete.valeur

    def queue(self):
        """Renvoie la queue de la liste."""
        if self.est_vide():
            raise IndexError("La liste vide n'a pas de queue")
        return ListeChaine(self.__tete.suivant)

    def ajoute(self, valeur):
        """ajoute `valeur` en tête de la liste."""
        self.__tete = Maillon(valeur, self.__tete)

    def __str__(self):
        """Renvoie une chaîne de caractères représentant la liste."""
        maillon = self.__tete
        s = ''
        while maillon is not None:
            s = s + str(maillon.valeur)
            maillon = maillon.suivant
            if maillon is not None:
                s += '->'
        return s

    def __len__(self):
        """Renvoie la longueur de la liste."""
        maillon = self.__tete
        long = 0
        while maillon is not None:
            long = long + 1
            maillon = maillon.suivant
        return long

    def __getitem__(self, n):
        """Renvoie l'élément d'indice n de la liste."""
        maillon = self.__tete
        i = 0
        while i < n and maillon is not None:
            i = i + 1
            maillon = maillon.suivant
        if maillon is None or n < 0:
            raise IndexError("Indice non valide")
        return maillon.valeur

    def __add__(self, other):
        """Renvoie la liste correspondant à la concaténation des 2 listes."""
        if self.est_vide():
            return other
        v = self.tete()
        q = self.queue()
        return ListeChaine(Maillon(v, (q + other).__tete))

    def reverse(self):
        """Renvoie une liste correspondant à la liste renversée."""
        res = ListeChaine()
        maillon = self.__tete
        while maillon is not None:
            res.ajoute(maillon.valeur)
            maillon = maillon.suivant
        return res


if __name__ == "__main__":
    lst = ListeChaine()
    print(lst.est_vide())
    lst.ajoute(306)
    lst.ajoute(42)
    lst.ajoute(205)
    print(lst)
    print(lst.est_vide())
    print(lst[0])
    print(lst[1])
    print(len(lst))
    lst2 = ListeChaine()
    lst2.ajoute(18)
    lst2.ajoute(45)
    print(lst + lst2)
