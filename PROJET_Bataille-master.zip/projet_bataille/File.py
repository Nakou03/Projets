#!/usr/bin/env python3
# -*- coding: utf-8 -*-

class File_lst:
    """Implémentation d'une file par une liste."""
    def __init__(self):
        """Crée une file vide."""
        self.__file = []

    def est_vide(self):
        """Indique si la file est vide."""
        return self.__file == []

    def enfiler(self, valeur):
        """Enfile l'élément valeur."""
        self.__file.append(valeur)

    def defiler(self):
        """Défile la tête de la file et la renvoie."""
        return self.__file.pop(0)

    def taille(self):
        """Renvoie la taille de la file."""
        return len(self.__file)

    def tete(self):
        """Renvoie la tête de la file (sans la défiler)."""
        return self.__file[0]

    def __str__(self):
        s = "tete->"
        for val in self.__file:
            s += str(val) + "->"
        return s + "queue"


class Maillon:
    """Un maillon d'une liste doublement chaînée."""
    def __init__(self, precedent, valeur, suivant):
        self.valeur = valeur
        self.precedent = precedent
        self.suivant = suivant

    def __str__(self):
        return str(self.valeur)


class File_chaine:
    """Implémentation d'une file par une liste doublement chaînée."""
    def __init__(self):
        """Crée une file vide."""
        self.__debut = self.__fin = None
        self.__taille = 0

    def est_vide(self):
        """Indique si la file est vide."""
        return self.__taille == 0

    def enfiler(self, valeur):
        """Enfile l'élément valeur."""
        maillon = Maillon(self.__fin, valeur, None)
        if self.est_vide():
            self.__debut = self.__fin = maillon
        else:
            self.__fin.suivant = maillon
            self.__fin = maillon
        self.__taille += 1

    def defiler(self):
        """Défile la tête de la file et la renvoie."""
        if self.est_vide():
            raise IndexError("Impossible de défiler une file vide.")
        valeur = self.__debut.valeur
        self.__taille -= 1
        if self.est_vide():
            self.__debut = self.__fin = None
        else:
            self.__debut = self.__debut.suivant
            self.__debut.precedent = None
        return valeur

    def taille(self):
        """Renvoie la taille de la file."""
        return self.__taille

    def tete(self):
        """Renvoie la tête de la file (sans la défiler)."""
        if self.est_vide():
            raise IndexError("Une file vide n'a pas de tête.")
        return self.__debut.valeur

    def __str__(self):
        s = "tete->"
        maillon = self.__debut
        while maillon is not None:
            s += str(maillon) + "->"
            maillon = maillon.suivant
        return s + "queue"


if __name__ == "__main__":
    f = File_lst()
    print(f.est_vide())
    f.enfiler('A')
    f.enfiler('B')
    f.enfiler('C')
    print(f.est_vide())
    print(f.tete())
    print(f)
    print(f.taille())
    print(f.defiler())
    print(f.defiler())
    print(f.defiler())
    print(f.est_vide())
