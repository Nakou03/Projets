# Mathis et ???

# Utilisation de get dans un dictionnaire, f-string,  non vue
# Dans un jeu de 32, les valeurs ne vont pas du 2 au 9, mais du 7 à l'as !!
# Le cas d'une bataille multiple ne fonctionne pas : les valeurs de cartes_j1 et cartes_j2 sont perdues ....
# Interface graphique trop minimale : il manque un "état des lieux"

# Note : 17


from File import File_chaine as File
from Pile import Pile_chaine as Pile
import random
import tkinter as tk


class Carte:
    def __init__(self, valeur, couleur):
        """créer une carte d'une valeur(qui peut etre un entier ou un chaine de
        caractere correspondant à valet, dame, roi, as) entre
        1 et 14 où 11, 12, 13, 14/1 sont respectivement valet, dame, roi, as"""
        self.valeur = {"valet": 11, "dame": 12, "roi": 13, "as": 14}.get(valeur, valeur)
        self.couleur = couleur
        
    def __str__(self):
        """permet d'afficher une carte sous la forme: |"valet de coeur" si self.valeur == 11 et self.couleur == "coeur"|
        et |"7 de pique" si self.valeur == 7 et self.couleur == "pique"|."""
        valeurs = {11: "valet", 12: "dame", 13: "roi", 14: "as"}
        return f"{valeurs.get(self.valeur, self.valeur)} de {self.couleur}"
    
    def compare(self, other):
        """une méthode qui compare les cartes et qui renvoie 1 si notre carte est >,
        -1 si notre carte est < et 0 si elles sont egales"""
        if self.valeur > other.valeur:
            return 1
        elif self.valeur < other.valeur:
            return -1
        return 0

class Jeux:
    def __init__(self, nb_cartes=32):
        """Créer une liste de carte de 32 ou 52 cartes en utilisant la class carte. La liste est
        mélangée aléatoirement puis empilée dans le paquet. Le paquet est une pile."""
        if nb_cartes not in (32, 52):
            raise ValueError("Le nombre de cartes doit être 32 ou 52.")
        self.paquet = Pile()
        cartes = []
        for c in ('trefle', 'carreau', 'coeur', 'pique'):
            for v in range (2, int(nb_cartes / 4) + 2):
                cartes.append(Carte(v, c))
        random.shuffle(cartes)
        for carte in cartes:
            self.paquet.empiler(carte)
        
    def distribue(self):
        """Une methode qui renvoie deux Files contenant la moitié des cartes du paquet chacune."""
        j1 = File()
        j2 = File()
        while not self.paquet.est_vide():
            j1.enfiler(self.paquet.depiler())
            if not self.paquet.est_vide():
                j2.enfiler(self.paquet.depiler())
        return j1, j2

class JeuBataille:
    def __init__(self, root):
        self.jeu = Jeux(32)
        self.j1, self.j2 = self.jeu.distribue()
        self.resultat = tk.StringVar(root)  # Associe StringVar à root
        self.resultat.set("Cliquez sur 'Jouer' pour commencer.")

    def jouer_tour(self):
        if self.j1.est_vide():
            self.resultat.set("Vous avez perdu !")
            return
        if self.j2.est_vide():
            self.resultat.set("Vous avez gagné !")
            return

        c1 = self.j1.defiler()
        c2 = self.j2.defiler()
        resultat = c1.compare(c2)

        if resultat > 0:
            self.j1.enfiler(c1)
            self.j1.enfiler(c2)
            self.resultat.set(f"Vous jouez {c1}, l'ordinateur joue {c2}. Vous gagnez ce tour.")
        elif resultat < 0:
            self.j2.enfiler(c1)
            self.j2.enfiler(c2)
            self.resultat.set(f"Vous jouez {c1}, l'ordinateur joue {c2}. L'ordinateur gagne ce tour.")
        else:
            self.resultat.set(f"Vous jouez {c1}, l'ordinateur joue {c2}. Égalité, bataille !")
            self.bataille(c1, c2)

    def bataille(self, c1, c2):
        if self.j1.taille() < 2 or self.j2.taille() < 2:
            self.resultat.set("Bataille impossible, un joueur manque de cartes.")
            return
        cartes_j1 = [c1, self.j1.defiler(), self.j1.defiler()]
        cartes_j2 = [c2, self.j2.defiler(), self.j2.defiler()]
        nouveau_c1 = cartes_j1.pop()
        nouveau_c2 = cartes_j2.pop()
        resultat = nouveau_c1.compare(nouveau_c2)

        if resultat > 0:
            for carte in cartes_j1 + cartes_j2 + [nouveau_c1, nouveau_c2]:
                self.j1.enfiler(carte)
            self.resultat.set("Vous gagnez la bataille !")
        elif resultat < 0:
            for carte in cartes_j1 + cartes_j2 + [nouveau_c1, nouveau_c2]:
                self.j2.enfiler(carte)
            self.resultat.set("L'ordinateur gagne la bataille.")
        else:
            self.resultat.set("Nouvelle égalité, bataille encore !")
            self.bataille(nouveau_c1, nouveau_c2)

def interface():
    root = tk.Tk()  # Crée la fenêtre principale en premier
    root.title("Jeu de Bataille")

    jeu = JeuBataille(root)  # Passe root en paramètre
    
    tk.Label(root, text="Jeu de Bataille", font=("Helvetica", 16)).pack(pady=10)
    tk.Label(root, textvariable=jeu.resultat, wraplength=300).pack(pady=20)
    
    btn_jouer = tk.Button(root, text="Jouer un tour", command=jeu.jouer_tour)
    btn_jouer.pack(pady=10)
    
    root.mainloop()

if __name__ == "__main__":
    interface()