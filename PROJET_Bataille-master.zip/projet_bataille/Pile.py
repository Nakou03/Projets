#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from listeChaine import ListeChaine

class Pile_lst:
    """Implémentation d'une pile par une liste."""
    def __init__(self):
        """Crée une pile vide."""
        self.__pile = []

    def est_vide(self):
        """Indique si la pile est vide."""
        return self.__pile == []

    def empiler(self, valeur):
        """Empile la valeur."""
        self.__pile.append(valeur)

    def depiler(self):
        """Dépile le sommet de la pile et le renvoie."""
        return self.__pile.pop()

    def taille(self):
        """Renvoie la taille de la pile."""
        return len(self.__pile)

    def sommet(self):
        """Renvoie le sommet de la pile (sans le dépiler)."""
        return self.__pile[-1]

    def __str__(self):
        s = "|"
        for val in self.__pile:
            s = str(val) + "->" + s
        return s


class Pile_chaine:
    """Implémentation d'une pile par une liste chaînée."""
    def __init__(self):
        """Crée une pile vide."""
        self.__pile = ListeChaine()
        self.__taille = 0

    def est_vide(self):
        """Indique si la pile est vide."""
        return self.__taille == 0

    def empiler(self, valeur):
        """Empile la valeur."""
        self.__pile.ajoute(valeur)
        self.__taille += 1

    def depiler(self):
        """Dépile le sommet de la pile et le renvoie."""
        if self.est_vide():
            raise IndexError("Impossible de dépiler une pile vide.")
        valeur = self.__pile.tete()
        self.__pile = self.__pile.queue()
        self.__taille -= 1
        return valeur

    def taille(self):
        """Renvoie la taille de la pile."""
        return self.__taille

    def sommet(self):
        """Renvoie le sommet de la pile (sans le dépiler)."""
        if self.est_vide():
            raise IndexError("Une pile vide n'a pas de sommet.")
        return self.__pile.tete()

    def __str__(self):
        return str(self.__pile) + "->|"


if __name__ == "__main__":
    p = Pile_lst()
    print(p.est_vide())
    p.empiler('A')
    p.empiler('B')
    p.empiler('C')
    print(p.est_vide())
    print(p.sommet())
    print(p)
    print(p.taille())
    print(p.depiler())
    print(p.depiler())
    print(p.depiler())
    print(p.est_vide())
