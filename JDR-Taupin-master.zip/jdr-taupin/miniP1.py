### programme fonctionnel mais pas de gestion d'erreur pour le choix de la catégorie
### la classe respecte le cahier des charges
### les tests pour changer de tour ne sont pas très lisibles, si le player_1 n'a plus de pdv
### on lance un autre combat ?
### la partie programme principal demande à être mieux organisée
### note : 18/20 (classe : 12/12 prog : 6/8)

from random import randint
class Personnage:  
    def __init__(self, nom, cat):
        self.nom = nom
        self.pdv = 20
        self.exp = 1
        self.cat = cat
        self.potions = 1  # Nombre de potions par défaut car sa je trouve pas sinon ou les mettre
        if self.cat == "guerrier":
            self.inventaire = ["épée", "potion"]
        elif self.cat == "magicien":
            self.inventaire = ["bâton", "potion"]
        elif self.cat == "voleur":
            self.inventaire = ["dague", "potion"]
        elif self.cat == "elfe":
            self.inventaire = ["arc", "potion"]

    def jet_attaque(self):
        if self.cat == "guerrier":
            return randint(1, 20) + self.exp * 10
        elif self.cat == "magicien":
            return randint(1, 20) + self.exp * 10
        elif self.cat == "voleur":
            return randint(1, 20) + self.exp * 3
        elif self.cat == "elfe":
            return randint(1, 20) + self.exp * 8

    def jet_defense(self):
        if self.cat == "guerrier":
            return randint(1, 20) + self.exp * 8
        elif self.cat == "magicien":
            return randint(1, 20) + self.exp * 7
        elif self.cat == "voleur":
            return randint(1, 20) + self.exp * 9
        elif self.cat == "elfe":
            return randint(1, 20) + self.exp * 10

    def change_pdv(self, nb_pdv):
        self.pdv = max(0, self.pdv + nb_pdv)  # Les points de vie ne peuvent pas être négatifs enfin je croi. Pourquoi pas

    def change_exp(self, nb_exp):
        self.exp += nb_exp

    def affiche_caracteristiques(self):
        print ("ton nom es",self.nom,"tu es un(e)",self.cat,"tu as",self.pdv,"pv","et",self.exp,"exp")

    def affiche_inventaire(self):
       print ("ton inventaire",self.inventaire)

    def utiliser_potion(self):
        if self.potions > 0:
            self.change_pdv(10)
            self.potions -= 1
            print( self.nom, "utilise une potion ! Il reste ",self.potions," potion.")
        else:
            print( self.nom, "a plus de potions !")


def game():
    Player_1_nom = input("Comment vous appelez-vous, joueur 1 ? ")
    print("Bonjour cher", Player_1_nom)
    Player_1_cat = input("Quelle catégorie voulez-vous être ? \n1: Guerrier \n2: Magicien \n3: Voleur \n4: Elfe\n")
    
    if Player_1_cat == "1":
        Player_1_cat = "guerrier"
    elif Player_1_cat == "2":
        Player_1_cat = "magicien"
    elif Player_1_cat == "3":
        Player_1_cat = "voleur"
    elif Player_1_cat == "4":
        Player_1_cat = "elfe"

    print("Vous etes maintenant un(e)", Player_1_cat)
    
    Player_2_nom = input("À votre tour, Player 2, comment vous appelez-vous ? ")
    print("Bonjour cher", Player_2_nom)
    Player_2_cat = input("Quelle catégorie voulez-vous être ? \n1: Guerrier \n2: Magicien \n3: Voleur \n4: Elfe\n")

    if Player_2_cat == "1":
        Player_2_cat = "guerrier"
    elif Player_2_cat == "2":
        Player_2_cat = "magicien"
    elif Player_2_cat == "3":
        Player_2_cat = "voleur"
    elif Player_2_cat == "4":
        Player_2_cat = "elfe"

    print("Vous etes maintenant un(e)", Player_2_cat)
    
    #les joueur ;)
    Player_1 = Personnage(Player_1_nom, Player_1_cat)
    Player_2 = Personnage(Player_2_nom, Player_2_cat)
    
    return Player_1, Player_2



def tour(attaquant, defenseur):
    action = input(attaquant.nom + " vous pouvez attaquer ou utiliser une potion de soins (il vous reste " + str(attaquant.potions) + " potion(s)).\n"
                   + "Quelle est votre action ? (A pour attaquer / P pour utiliser une potion) ")

    if action == "A":#il y a un probleme que j'arrive pas a resoudre c'est si la personne mes pas en majuscule sa fonctionne pas. C'est bizarre!
        attaque = attaquant.jet_attaque()
        defense = defenseur.jet_defense()
        print(attaquant.nom + " attaque avec un score de " + str(attaque) + " !")
        print(defenseur.nom + " se défend avec un score de " + str(defense) + " !")

        if attaque > defense:
            dommages = -randint(1, 8)
            defenseur.change_pdv(dommages)
            print(defenseur.nom + " subit " + str(-dommages) + " points de dégâts !")
        else:
            dommages = -randint(1, 4)
            attaquant.change_pdv(dommages)
            print(attaquant.nom + " subit " + str(-dommages) + " points de dégâts !")
            print(defenseur.nom + " parvient à se défendre !")
    
    elif action == "P":
        attaquant.utiliser_potion()

    attaquant.affiche_caracteristiques()
    defenseur.affiche_caracteristiques()


# Lancer la partie je me suis aider sur internet pour la fin comment arreter la boucle grace au break.
Player_1, Player_2 = game()

while Player_1.pdv > 0 and Player_2.pdv > 0:
    tour(Player_1, Player_2)
    if Player_2.pdv <= 0:
        print(Player_1.nom + " a gagné !")
        break
    tour(Player_2, Player_1)
    if Player_1.pdv <= 0:
        print(Player_2.nom + " a gagné !")#je ne sais pas pourquoi se ne met pas que le gagnant a gagner.